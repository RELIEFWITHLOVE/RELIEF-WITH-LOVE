# RELIEFFORLOVE

Official website and fundraising platform for **RELIEFFORLOVE**.

## Project goals

- Present the foundation's mission and programs
- Share impact and community stories
- Accept donations through a secure payment provider
- Provide a clear path for volunteers, partners and supporters

## Technology

- HTML5
- CSS3
- Vanilla JavaScript

## Structure

- `index.html` — homepage
- `about.html` — foundation information
- `programs.html` — programs and campaigns
- `donate.html` — donation experience
- `contact.html` — contact page
- `css/` — site styles
- `js/` — site behavior
- `images/` — foundation images
- `docs/` — project and fundraising notes

## Getting started

Open `index.html` in a browser, or publish the repository with GitHub Pages.

Before launch, replace all `RELIEFFORLOVE` placeholders, add official contact information, replace sample impact figures, add real images, and connect `donate.html` to a secure payment provider.

## Donation security

Do **not** collect or store card numbers, CVVs, passwords, or other payment credentials in this static site. Use the hosted checkout or official API flow provided by your payment processor.

## Deployment

For GitHub Pages:

1. Push this project to a GitHub repository.
2. Open the repository's **Settings → Pages**.
3. Select the deployment source/branch containing the site.
4. Save and open the generated Pages URL.

## License

Choose an appropriate license for the foundation before publishing the repository.
