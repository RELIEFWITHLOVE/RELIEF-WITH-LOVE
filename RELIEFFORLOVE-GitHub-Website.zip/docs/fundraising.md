# Fundraising

## Donation flow

1. Supporter chooses an amount.
2. Supporter is sent to a trusted payment checkout.
3. Payment provider processes the transaction.
4. The foundation receives confirmation through the provider's secure system.
5. Donation records are handled according to the foundation's privacy and accounting policies.

## Before production

- Choose a payment processor available in the foundation's target countries.
- Create the merchant/business account.
- Configure the secure checkout.
- Add the provider's official integration.
- Configure webhooks/server-side verification if required.
- Publish a privacy notice and donation terms.
- Test successful, failed and cancelled payments.
- Confirm how receipts and donor records will be handled.

Never place secret API keys in frontend JavaScript or commit them to GitHub.
