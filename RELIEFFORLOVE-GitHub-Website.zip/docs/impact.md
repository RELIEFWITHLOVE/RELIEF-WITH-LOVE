# Impact

Replace this document with verified impact information.

## Current impact

- People reached: 0
- Programs delivered: 0
- Volunteers: 0
- Communities supported: 0

## Reporting principles

Publish figures that are accurate, dated and explain how they were measured. Update this document as new verified results become available.
